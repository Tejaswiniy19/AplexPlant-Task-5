<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$post_id = $data['post_id'] ?? 0;
$content = trim($data['content'] ?? '');
$user_id = $_SESSION['user_id'];

if (empty($content)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['success' => false, 'error' => 'Comment cannot be empty']);
    exit();
}

$stmt = $pdo->prepare("INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)");
$stmt->execute([$user_id, $post_id, $content]);

echo json_encode(['success' => true]);
?>