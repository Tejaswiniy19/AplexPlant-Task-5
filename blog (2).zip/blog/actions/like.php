<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$post_id = $data['post_id'] ?? 0;
$user_id = $_SESSION['user_id'];

// Check if already liked
$stmt = $pdo->prepare("SELECT * FROM likes WHERE user_id = ? AND post_id = ?");
$stmt->execute([$user_id, $post_id]);
$existing = $stmt->fetch();

if ($existing) {
    // Unlike
    $stmt = $pdo->prepare("DELETE FROM likes WHERE id = ?");
    $stmt->execute([$existing['id']]);
    $action = 'unliked';
} else {
    // Like
    $stmt = $pdo->prepare("INSERT INTO likes (user_id, post_id) VALUES (?, ?)");
    $stmt->execute([$user_id, $post_id]);
    $action = 'liked';
}

// Get updated like count
$stmt = $pdo->prepare("SELECT COUNT(*) as like_count FROM likes WHERE post_id = ?");
$stmt->execute([$post_id]);
$like_count = $stmt->fetch()['like_count'];

echo json_encode([
    'success' => true,
    'action' => $action,
    'like_count' => $like_count
]);
?>