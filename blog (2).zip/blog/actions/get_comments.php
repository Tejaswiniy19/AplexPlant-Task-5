<?php
require '../db.php';

$post_id = $_GET['post_id'] ?? 0;

$stmt = $pdo->prepare("
    SELECT comments.*, users.username 
    FROM comments 
    JOIN users ON comments.user_id = users.id 
    WHERE post_id = ? 
    ORDER BY created_at DESC
    LIMIT 5
");
$stmt->execute([$post_id]);
$comments = $stmt->fetchAll();

header('Content-Type: application/json');
echo json_encode($comments);
?>