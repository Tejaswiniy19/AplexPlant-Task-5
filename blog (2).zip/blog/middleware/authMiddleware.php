<?php
require_once __DIR__ . '/../auth/Auth.php';

$auth = new Auth($pdo);

// Common permission check functions
function requireAdmin() {
    global $auth;
    $auth->requireRole('admin');
}

function requireEditor() {
    global $auth;
    // Editors can be either users with editor role or admin
    if (!$auth->hasRole($_SESSION['user_id'], 'editor') && !$auth->hasRole($_SESSION['user_id'], 'admin')) {
        header('HTTP/1.0 403 Forbidden');
        include '../errors/403.php';
        exit;
    }
}

function requireAuthor() {
    global $auth;
    if (!$auth->hasPermission($_SESSION['user_id'], 'create_post')) {
        header('HTTP/1.0 403 Forbidden');
        include '../errors/403.php';
        exit;
    }
}

// Post ownership check
function requirePostOwnershipOrPermission($postId, $permission) {
    global $auth, $pdo;
    
    // Admins can do anything
    if ($auth->hasRole($_SESSION['user_id'], 'admin')) {
        return;
    }
    
    // Check if user has the required permission (like edit_any_post)
    if ($auth->hasPermission($_SESSION['user_id'], $permission)) {
        return;
    }
    
    // Verify post ownership
    $stmt = $pdo->prepare("SELECT user_id FROM posts WHERE id = ?");
    $stmt->execute([$postId]);
    $post = $stmt->fetch();
    
    if ($post && $post['user_id'] == $_SESSION['user_id']) {
        return;
    }
    
    header('HTTP/1.0 403 Forbidden');
    include '../errors/403.php';
    exit;
}
?>