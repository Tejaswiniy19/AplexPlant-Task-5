<?php
session_start();
require '../db.php';
require_once __DIR__ . '/../middleware/authMiddleware.php';

// Get post ID from URL
$postId = $_GET['id'] ?? 0;

// Check permissions
requirePostOwnershipOrPermission($postId, 'edit_any_post');

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$post_id = $_GET['id'] ?? 0;

// Verify post ownership
$stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $_SESSION['user_id']]);
$post = $stmt->fetch();

if (!$post) {
    header("Location: ../index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    
    // Handle image update
    $image_path = $post['image_path'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        // Delete old image if exists
        if (!empty($image_path) && file_exists("../$image_path")) {
            unlink("../$image_path");
        }
        
        // Upload new image
        $upload_dir = '../uploads/';
        $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_path = $upload_dir . $file_name;
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = $_FILES['image']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                $image_path = 'uploads/' . $file_name;
            }
        }
    }
    
    // Handle image removal
    if (isset($_POST['remove_image']) && !empty($image_path)) {
        if (file_exists("../$image_path")) {
            unlink("../$image_path");
        }
        $image_path = '';
    }
    
    $stmt = $pdo->prepare("UPDATE posts SET title = ?, content = ?, image_path = ? WHERE id = ?");
    $stmt->execute([$title, $content, $image_path, $post_id]);
    header("Location: ../index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post | Modern Blog</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .edit-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 700px;
            padding: 40px;
            transform: translateY(0);
            opacity: 1;
            transition: all 0.5s ease;
        }
        
        .edit-header {
            margin-bottom: 30px;
            text-align: center;
        }
        
        .edit-header h2 {
            color: var(--primary);
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .edit-header p {
            color: #666;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        textarea.form-control {
            min-height: 200px;
            resize: vertical;
        }
        
        .btn {
            display: inline-block;
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn:hover {
            background-color: var(--secondary);
            transform: translateY(-2px);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .file-upload {
            position: relative;
            margin-bottom: 25px;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-upload-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            border: 2px dashed #e0e0e0;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .file-upload-label:hover {
            border-color: var(--primary);
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .file-upload-label i {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .file-upload-label span {
            color: #666;
        }
        
        .file-name {
            margin-top: 10px;
            font-size: 0.9rem;
            color: var(--primary);
            font-weight: 500;
        }
        
        .current-image {
            margin: 20px 0;
            text-align: center;
        }
        
        .current-image img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 15px;
        }
        
        .remove-image {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .remove-image input[type="checkbox"] {
            margin-right: 10px;
            width: 18px;
            height: 18px;
            accent-color: var(--danger);
        }
        
        .remove-image label {
            color: var(--danger);
            font-weight: 500;
            cursor: pointer;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .back-link:hover {
            color: var(--secondary);
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .edit-container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="edit-container">
        <div class="edit-header">
            <h2><i class="fas fa-edit"></i> Edit Post</h2>
            <p>Update your post content</p>
        </div>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Post Title</label>
                <input type="text" name="title" id="title" class="form-control" 
                       value="<?= htmlspecialchars($post['title']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="content">Post Content</label>
                <textarea name="content" id="content" class="form-control" 
                          required><?= htmlspecialchars($post['content']) ?></textarea>
            </div>
            
            <?php if (!empty($post['image_path'])): ?>
                <div class="current-image">
                    <img src="../<?= htmlspecialchars($post['image_path']) ?>" alt="Current post image">
                    <div class="remove-image">
                        <input type="checkbox" name="remove_image" id="remove_image">
                        <label for="remove_image">Remove current image</label>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="file-upload">
                <label class="file-upload-label" for="image">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <span>Click to upload a new image or drag and drop</span>
                    <span class="file-name" id="file-name">No file chosen</span>
                </label>
                <input type="file" name="image" id="image" accept="image/*">
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-save"></i> Update Post
            </button>
        </form>
        
        <a href="../index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Home</a>
    </div>

    <script>
        // Animation for edit container
        document.addEventListener('DOMContentLoaded', () => {
            const editContainer = document.querySelector('.edit-container');
            editContainer.style.opacity = '0';
            editContainer.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                editContainer.style.opacity = '1';
                editContainer.style.transform = 'translateY(0)';
            }, 100);
            
            // File upload name display
            const fileInput = document.getElementById('image');
            const fileName = document.getElementById('file-name');
            
            fileInput.addEventListener('change', (e) => {
                if (fileInput.files.length > 0) {
                    fileName.textContent = fileInput.files[0].name;
                } else {
                    fileName.textContent = 'No file chosen';
                }
            });
            
            // Form validation
            document.querySelector('form').addEventListener('submit', (e) => {
                const title = document.getElementById('title').value.trim();
                const content = document.getElementById('content').value.trim();
                
                if (!title || !content) {
                    e.preventDefault();
                    alert('Please fill in all required fields');
                }
            });
        });
    </script>
</body>
</html>