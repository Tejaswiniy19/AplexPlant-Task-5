<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$post_id = $_GET['id'] ?? 0;

// Verify ownership and delete
$stmt = $pdo->prepare("SELECT image_path FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$post_id, $_SESSION['user_id']]);
$post = $stmt->fetch();

if ($post) {
    // Delete associated image
    if (!empty($post['image_path']) && file_exists("../".$post['image_path'])) {
        unlink("../".$post['image_path']);
    }
    
    // Delete post
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->execute([$post_id]);
}

header("Location: ../index.php");
exit();
?>