<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $user_id = $_SESSION['user_id'];
    $is_video = 0;
    $media_path = '';
    $error = '';
    
    // Handle file upload
    if (isset($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $file_ext = strtolower(pathinfo($_FILES['media']['name'], PATHINFO_EXTENSION));
        $file_name = uniqid() . '.' . $file_ext;
        $target_path = $upload_dir . $file_name;
        
        // Check if it's a video
        $video_extensions = ['mp4', 'mov', 'avi', 'webm'];
        if (in_array($file_ext, $video_extensions)) {
            // Validate video duration (requires FFmpeg)
            $duration = 0;
            if (function_exists('shell_exec')) {
                $ffprobe = shell_exec("ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 " . escapeshellarg($_FILES['media']['tmp_name']));
                $duration = (float)$ffprobe;
            }
            
            if ($duration > 0 && ($duration < 30 || $duration > 45)) {
                $error = "Video must be between 30 and 45 seconds";
            } else {
                $is_video = 1;
                if (move_uploaded_file($_FILES['media']['tmp_name'], $target_path)) {
                    $media_path = 'uploads/' . $file_name;
                }
            }
        } else {
            // It's an image
            $allowed_image_types = ['image/jpeg', 'image/png', 'image/gif'];
            $file_type = $_FILES['media']['type'];
            
            if (in_array($file_type, $allowed_image_types)) {
                if (move_uploaded_file($_FILES['media']['tmp_name'], $target_path)) {
                    $media_path = 'uploads/' . $file_name;
                }
            } else {
                $error = "Invalid file type. Only images (JPEG, PNG, GIF) or videos (MP4, MOV, AVI) are allowed.";
            }
        }
    }
    
    if (empty($error)) {
        $stmt = $pdo->prepare("INSERT INTO posts (title, content, user_id, image_path, video_path, is_video) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $title,
            $content,
            $user_id,
            $is_video ? '' : $media_path, // image_path
            $is_video ? $media_path : '',  // video_path
            $is_video
        ]);
        header("Location: ../index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post | Modern Blog</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #4895ef;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #4cc9f0;
            --danger: #f72585;
            --warning: #f8961e;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .post-container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 700px;
            padding: 40px;
            transform: translateY(0);
            opacity: 1;
            transition: all 0.5s ease;
        }
        
        .post-header {
            margin-bottom: 30px;
            text-align: center;
        }
        
        .post-header h2 {
            color: var(--primary);
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .post-header p {
            color: #666;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark);
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        textarea.form-control {
            min-height: 200px;
            resize: vertical;
        }
        
        .btn {
            display: inline-block;
            background-color: var(--primary);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn:hover {
            background-color: var(--secondary);
            transform: translateY(-2px);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        .file-upload {
            position: relative;
            margin-bottom: 25px;
        }
        
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-upload-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 30px;
            border: 2px dashed #e0e0e0;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .file-upload-label:hover {
            border-color: var(--primary);
            background-color: rgba(67, 97, 238, 0.05);
        }
        
        .file-upload-label i {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 10px;
        }
        
        .file-upload-label span {
            color: #666;
        }
        
        .file-name {
            margin-top: 10px;
            font-size: 0.9rem;
            color: var(--primary);
            font-weight: 500;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .back-link:hover {
            color: var(--secondary);
            text-decoration: underline;
        }
        
        .error-message {
            color: var(--danger);
            background-color: rgba(247, 37, 133, 0.1);
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .error-message i {
            font-size: 1.2rem;
        }
        
        .duration-info {
            color: #666;
            font-size: 0.85rem;
            margin-top: 5px;
            font-style: italic;
        }
        
        @media (max-width: 768px) {
            .post-container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="post-container">
        <div class="post-header">
            <h2><i class="fas fa-plus-circle"></i> Create New Post</h2>
            <p>Share your thoughts with the community</p>
        </div>
        
        <?php if(!empty($error)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <span><?= $error ?></span>
            </div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Post Title</label>
                <input type="text" name="title" id="title" class="form-control" placeholder="Enter post title" required>
            </div>
            
            <div class="form-group">
                <label for="content">Post Content</label>
                <textarea name="content" id="content" class="form-control" placeholder="Write your post content here..." required></textarea>
            </div>
            
            <div class="file-upload">
                <label class="file-upload-label" for="media">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <span>Click to upload an image or video</span>
                    <span class="file-name" id="file-name">No file chosen</span>
                    <p class="duration-info">Videos must be 30-45 seconds long</p>
                </label>
                <input type="file" name="media" id="media" accept="image/*,video/*" required>
            </div>
            
            <button type="submit" class="btn">
                <i class="fas fa-paper-plane"></i> Publish Post
            </button>
        </form>
        
        <a href="../index.php" class="back-link"><i class="fas fa-arrow-left"></i> Back to Home</a>
    </div>

    <script>
        // Animation for post container
        document.addEventListener('DOMContentLoaded', () => {
            const postContainer = document.querySelector('.post-container');
            postContainer.style.opacity = '0';
            postContainer.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                postContainer.style.opacity = '1';
                postContainer.style.transform = 'translateY(0)';
            }, 100);
            
            // File upload name display
            const fileInput = document.getElementById('media');
            const fileName = document.getElementById('file-name');
            
            fileInput.addEventListener('change', (e) => {
                if (fileInput.files.length > 0) {
                    fileName.textContent = fileInput.files[0].name;
                    
                    // Client-side video duration check (approximate)
                    if (fileInput.files[0].type.includes('video')) {
                        const video = document.createElement('video');
                        video.preload = 'metadata';
                        
                        video.onloadedmetadata = function() {
                            window.URL.revokeObjectURL(video.src);
                            const duration = video.duration;
                            if (duration < 10 || duration > 4500) {
                                alert('Video must be between 30 and 45 seconds');
                                fileInput.value = '';
                                fileName.textContent = 'No file chosen';
                            }
                        };
                        
                        video.src = URL.createObjectURL(fileInput.files[0]);
                    }
                } else {
                    fileName.textContent = 'No file chosen';
                }
            });
            
            // Form validation
            document.querySelector('form').addEventListener('submit', (e) => {
                const title = document.getElementById('title').value.trim();
                const content = document.getElementById('content').value.trim();
                const media = document.getElementById('media').files.length;
                
                if (!title || !content || !media) {
                    e.preventDefault();
                    alert('Please fill in all required fields');
                }
            });
        });
    </script>
</body>
</html>