<?php
require_once __DIR__ . '/../db.php';

class Auth {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Check if user has a specific permission
    public function hasPermission($userId, $permissionName) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM user_role ur
            JOIN role_permission rp ON ur.role_id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE ur.user_id = ? AND p.name = ?
        ");
        $stmt->execute([$userId, $permissionName]);
        return $stmt->fetchColumn() > 0;
    }
    
    // Check if user has a specific role
    public function hasRole($userId, $roleName) {
        $stmt = $this->pdo->prepare("
            SELECT COUNT(*) FROM user_role ur
            JOIN roles r ON ur.role_id = r.id
            WHERE ur.user_id = ? AND r.name = ?
        ");
        $stmt->execute([$userId, $roleName]);
        return $stmt->fetchColumn() > 0;
    }
    
    // Middleware to require specific role
    public function requireRole($roleName) {
        if (!isset($_SESSION['user_id'])) {
            header('Location: auth/login.php');
            exit;
        }
        
        if (!$this->hasRole($_SESSION['user_id'], $roleName)) {
            header('HTTP/1.0 403 Forbidden');
            include 'errors/403.php';
            exit;
        }
    }
    
    // Middleware to require specific permission
    public function requirePermission($permissionName) {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /auth/login.php');
            exit;
        }
        
        if (!$this->hasPermission($_SESSION['user_id'], $permissionName)) {
            header('HTTP/1.0 403 Forbidden');
            include 'errors/403.php';
            exit;
        }
    }
    
    // Get all user permissions
    public function getUserPermissions($userId) {
        $stmt = $this->pdo->prepare("
            SELECT p.name FROM user_role ur
            JOIN role_permission rp ON ur.role_id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE ur.user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}
?>